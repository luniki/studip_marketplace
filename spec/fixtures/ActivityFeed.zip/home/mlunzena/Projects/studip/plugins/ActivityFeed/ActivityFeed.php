<?php
/*
 * ActivityFeed.class.php - activity feed plugin for Stud.IP
 * Copyright (c) 2010  Elmar Ludwig
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 */

require 'lib/forum.inc.php';

class ActivityFeed extends StudipPlugin implements SystemPlugin
{
    /**
     * plugin template factory
     */
    protected $template_factory;

    /**
     * Initialize a new instance of the plugin.
     */
    public function __construct()
    {
        parent::__construct();

        $template_path = $this->getPluginPath() . '/templates';
        $this->template_factory = new Flexi_TemplateFactory($template_path);

        $page = basename($_SERVER['PHP_SELF']);

        if (in_array($page, words('meine_seminare.php seminar_main.php institut_main.php'))) {
            $template = $this->template_factory->open('atom_link');
            $template->user_id = $GLOBALS['user']->id;
            $template->key = $this->get_user_key($GLOBALS['user']->id);
            $GLOBALS['_include_additional_header'] .= $template->render();
        }
    }

    /**
     * Calculate user specific access key.
     */
    private function get_user_key($user_id)
    {
        return sha1($user_id . ':' . get_config('ACTIVITY_FEED_KEY'));
    }

    /**
     * Return link to user's home page.
     */
    private function get_homepage($row)
    {
        $link = URLHelper::getLink('about.php', array('username' => $row['username']));

        return sprintf('<a href="%s">%s %s</a>', $link, $row['Vorname'], $row['Nachname']);
    }

    /**
     * Delete all characters outside the valid character range for XML
     * documents (#x9 | #xA | #xD | [#x20-#xD7FF] | [#xE000-#xFFFD]).
     */
    private function filter_xml_string($xml)
    {
        return preg_replace("/[^\t\n\r -\xFF]/", '', $xml);
    }

    /**
     * Display the atom activity feed for this user.
     */
    public function atom_action($user, $key)
    {
        $user_id = preg_replace('/\W/', '', $user);
        if ($this->get_user_key($user_id) != $key) {
            throw new Studip_AccessDeniedException('invalid access key');
        }

        header('Content-Type: application/atom+xml');
        $template = $this->template_factory->open('atom');

        $result = $this->get_activities($user_id);
        echo $this->filter_xml_string($template->render($result));
    }

    public function stream_action() {
        $activities = $this->get_activities($GLOBALS['user']->id);
        echo $this->template_factory->render('stream', $activities);
    }

    private function get_activities($user_id) {

        $db = DBManager::get();
        $days = Request::int('days', 100);
        $range = Request::option('cid');
        $chdate = time() - 24 * 60 * 60 * $days;
        $items = array();

        if (isset($range)) {
            $title = $GLOBALS['SessSemName'][0];
            $sem_filter = "seminar_user.user_id = '$user_id' AND Seminar_id = '$range'";
            $inst_filter = "user_inst.user_id = '$user_id' AND Institut_id = '$range'";
        } else {
            $title = $GLOBALS['UNI_NAME_CLEAN'];
            $sem_filter = "seminar_user.user_id = '$user_id'";
            $inst_filter = "user_inst.user_id = '$user_id'";
        }

        $sem_fields = 'auth_user_md5.user_id as author_id, auth_user_md5.username, auth_user_md5.Vorname, auth_user_md5.Nachname, seminare.Name';
        $inst_fields = 'auth_user_md5.user_id as author_id, auth_user_md5.username, auth_user_md5.Vorname, auth_user_md5.Nachname, Institute.Name';

        // forum

        $sql = "SELECT px_topics.*, $sem_fields
                FROM px_topics
                JOIN auth_user_md5 USING (user_id)
                JOIN seminar_user USING (Seminar_id)
                JOIN seminare USING (Seminar_id)
                WHERE $sem_filter AND px_topics.chdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['topic_id'],
                'title' => 'Forum: ' . $row['name'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('forum.php#anker',
                    array('cid' => $row['Seminar_id'], 'view' => 'tree', 'open' => $row['topic_id'])),
                'updated' => $row['chdate'],
                'summary' => sprintf('%s hat im Forum der Veranstaltung "%s" den Beitrag "%s" geschrieben.',
                    $this->get_homepage($row), $row['Name'], $row['name']),
                'content' => forum_kill_edit($row['description']),
                'category' => 'forum'
            );
        }

        $sql = "SELECT px_topics.*, $inst_fields
                FROM px_topics
                JOIN auth_user_md5 USING (user_id)
                JOIN user_inst ON (Seminar_id = Institut_id)
                JOIN Institute USING (Institut_id)
                WHERE $inst_filter AND px_topics.chdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['topic_id'],
                'title' => 'Forum: ' . $row['name'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('forum.php#anker',
                    array('cid' => $row['Institut_id'], 'view' => 'tree', 'open' => $row['topic_id'])),
                'updated' => $row['chdate'],
                'summary' => sprintf('%s hat im Forum der Einrichtung "%s" den Beitrag "%s" geschrieben.',
                    $this->get_homepage($row), $row['Name'], $row['name']),
                'content' => forum_kill_edit($row['description']),
                'category' => 'forum'
            );
        }

        // files

        $sql = "SELECT dokumente.*, $sem_fields
                FROM dokumente
                JOIN auth_user_md5 USING (user_id)
                JOIN seminar_user USING (Seminar_id)
                JOIN seminare USING (Seminar_id)
                WHERE $sem_filter AND dokumente.chdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['dokument_id'],
                'title' => 'Datei: ' . $row['name'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('folder.php#anker',
                    array('cid' => $row['seminar_id'], 'cmd' => 'tree', 'open' => $row['dokument_id'])),
                'updated' => $row['chdate'],
                'summary' => sprintf('%s hat im Dateibereich der Veranstaltung "%s" die Datei "%s" hochgeladen.',
                    $this->get_homepage($row), $row['Name'], $row['name']),
                'content' => $row['description'],
                'category' => 'files'
            );
        }

        $sql = "SELECT dokumente.*, $inst_fields
                FROM dokumente
                JOIN auth_user_md5 USING (user_id)
                JOIN user_inst ON (seminar_id = Institut_id)
                JOIN Institute USING (Institut_id)
                WHERE $inst_filter AND dokumente.chdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['dokument_id'],
                'title' => 'Datei: ' . $row['name'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('folder.php#anker',
                    array('cid' => $row['Institut_id'], 'cmd' => 'tree', 'open' => $row['dokument_id'])),
                'updated' => $row['chdate'],
                'summary' => sprintf('%s hat im Dateibereich der Einrichtung "%s" die Datei "%s" hochgeladen.',
                    $this->get_homepage($row), $row['Name'], $row['name']),
                'content' => $row['description'],
                'category' => 'files'
            );
        }

        // wiki

        $sql = "SELECT wiki.*, $sem_fields
                FROM wiki
                JOIN auth_user_md5 USING (user_id)
                JOIN seminar_user ON (range_id = Seminar_id)
                JOIN seminare USING (Seminar_id)
                WHERE $sem_filter AND wiki.chdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => md5($row['range_id'] . ':' . $row['keyword'] . ':' . $row['version']),
                'title' => 'Wiki: ' . $row['keyword'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('wiki.php',
                    array('cid' => $row['range_id'], 'keyword' => $row['keyword'])),
                'updated' => $row['chdate'],
                'summary' => sprintf('%s hat im Wiki der Veranstaltung "%s" die Seite "%s" ge�ndert.',
                    $this->get_homepage($row), $row['Name'], $row['keyword']),
                'content' => $row['body'],
                'category' => 'wiki'
            );
        }

        $sql = "SELECT wiki.*, $inst_fields
                FROM wiki
                JOIN auth_user_md5 USING (user_id)
                JOIN user_inst ON (range_id = Institut_id)
                JOIN Institute USING (Institut_id)
                WHERE $inst_filter AND wiki.chdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => md5($row['range_id'] . ':' . $row['keyword'] . ':' . $row['version']),
                'title' => 'Wiki: ' . $row['keyword'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('wiki.php',
                    array('cid' => $row['range_id'], 'keyword' => $row['keyword'])),
                'updated' => $row['chdate'],
                'summary' => sprintf('%s hat im Wiki der Einrichtung "%s" die Seite "%s" ge�ndert.',
                    $this->get_homepage($row), $row['Name'], $row['keyword']),
                'content' => $row['body'],
                'category' => 'files'
            );
        }

        // scm

        $sql = "SELECT scm.*, $sem_fields
                FROM scm
                JOIN auth_user_md5 USING (user_id)
                JOIN seminar_user ON (range_id = Seminar_id)
                JOIN seminare USING (Seminar_id)
                WHERE $sem_filter AND scm.chdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['scm_id'],
                'title' => 'Info: ' . $row['tab_name'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('scm.php',
                    array('cid' => $row['range_id'], 'show_scm' => $row['scm_id'])),
                'updated' => $row['chdate'],
                'summary' => sprintf('%s hat in der Veranstaltung "%s" die Informationsseite "%s" ge�ndert.',
                    $this->get_homepage($row), $row['Name'], $row['tab_name']),
                'content' => $row['content'],
                'category' => 'info'
            );
        }

        $sql = "SELECT scm.*, $inst_fields
                FROM scm
                JOIN auth_user_md5 USING (user_id)
                JOIN user_inst ON (range_id = Institut_id)
                JOIN Institute USING (Institut_id)
                WHERE $inst_filter AND scm.chdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['scm_id'],
                'title' => 'Info: ' . $row['tab_name'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('scm.php',
                    array('cid' => $row['range_id'], 'show_scm' => $row['scm_id'])),
                'updated' => $row['chdate'],
                'summary' => sprintf('%s hat in der Einrichtung "%s" die Informationsseite "%s" ge�ndert.',
                    $this->get_homepage($row), $row['Name'], $row['tab_name']),
                'content' => $row['content'],
                'category' => 'info'
            );
        }

        // news

        $sql = "SELECT news.*, news_range.range_id, $sem_fields
                FROM news
                JOIN news_range USING (news_id)
                JOIN auth_user_md5 USING (user_id)
                JOIN seminar_user ON (range_id = Seminar_id)
                JOIN seminare USING (Seminar_id)
                WHERE $sem_filter AND news.date > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['news_id'],
                'title' => 'News: ' . $row['topic'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('seminar_main.php#anker',
                    array('cid' => $row['range_id'], 'nopen' => $row['news_id'])),
                'updated' => $row['date'],
                'summary' => sprintf('%s hat in der Veranstaltung "%s" die News "%s" eingestellt.',
                    $this->get_homepage($row), $row['Name'], $row['topic']),
                'content' => $row['body'],
                'category' => 'news'
            );
        }

        $sql = "SELECT news.*, news_range.range_id, $inst_fields
                FROM news
                JOIN news_range USING (news_id)
                JOIN auth_user_md5 USING (user_id)
                JOIN user_inst ON (range_id = Institut_id)
                JOIN Institute USING (Institut_id)
                WHERE $inst_filter AND news.date > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['news_id'],
                'title' => 'News: ' . $row['topic'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('institut_main.php#anker',
                    array('cid' => $row['range_id'], 'nopen' => $row['news_id'])),
                'updated' => $row['date'],
                'summary' => sprintf('%s hat in der Einrichtung "%s" die News "%s" eingestellt.',
                    $this->get_homepage($row), $row['Name'], $row['topic']),
                'content' => $row['body'],
                'category' => 'news'
            );
        }

        // votes

        $sql = "SELECT vote.*, $sem_fields
                FROM vote
                JOIN auth_user_md5 ON (author_id = user_id)
                JOIN seminar_user ON (range_id = Seminar_id)
                JOIN seminare USING (Seminar_id)
                WHERE $sem_filter AND vote.startdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['vote_id'],
                'title' => 'Voting: ' . $row['title'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('seminar_main.php#openvote',
                    array('cid' => $row['range_id'], 'voteopenID' => $row['vote_id'])),
                'updated' => $row['startdate'],
                'summary' => sprintf('%s hat in der Veranstaltung "%s" die Abstimmung "%s" gestartet.',
                    $this->get_homepage($row), $row['Name'], $row['title']),
                'content' => $row['question'],
                'category' => 'voting'
            );
        }

        $sql = "SELECT vote.*, $inst_fields
                FROM vote
                JOIN auth_user_md5 ON (author_id = user_id)
                JOIN user_inst ON (range_id = Institut_id)
                JOIN Institute USING (Institut_id)
                WHERE $inst_filter AND vote.startdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['vote_id'],
                'title' => 'Voting: ' . $row['title'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('institut_main.php#openvote',
                    array('cid' => $row['range_id'], 'voteopenID' => $row['vote_id'])),
                'updated' => $row['startdate'],
                'summary' => sprintf('%s hat in der Einrichtung "%s" die Abstimmung "%s" gestartet.',
                    $this->get_homepage($row), $row['Name'], $row['title']),
                'content' => $row['question'],
                'category' => 'voting'
            );
        }

        // evaluations

        $sql = "SELECT eval.*, $sem_fields
                FROM eval
                JOIN eval_range USING (eval_id)
                JOIN auth_user_md5 ON (author_id = user_id)
                JOIN seminar_user ON (range_id = Seminar_id)
                JOIN seminare USING (Seminar_id)
                WHERE $sem_filter AND eval.startdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['eval_id'],
                'title' => 'Umfrage: ' . $row['title'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('seminar_main.php#openvote',
                    array('cid' => $row['range_id'], 'voteopenID' => $row['eval_id'])),
                'updated' => $row['startdate'],
                'summary' => sprintf('%s hat in der Veranstaltung "%s" die Umfrage "%s" gestartet.',
                    $this->get_homepage($row), $row['Name'], $row['title']),
                'content' => $row['text'],
                'category' => 'survey'
            );
        }

        $sql = "SELECT eval.*, $inst_fields
                FROM eval
                JOIN eval_range USING (eval_id)
                JOIN auth_user_md5 ON (author_id = user_id)
                JOIN user_inst ON (range_id = Institut_id)
                JOIN Institute USING (Institut_id)
                WHERE $inst_filter AND eval.startdate > $chdate";

        $result = $db->query($sql);

        foreach ($result as $row) {
            $items[] = array(
                'id' => $row['eval_id'],
                'title' => 'Umfrage: ' . $row['title'],
                'author' => $row['Vorname'] . ' ' . $row['Nachname'],
                'author_id' => $row['author_id'],
                'link' => URLHelper::getLink('institut_main.php#openvote',
                    array('cid' => $row['range_id'], 'voteopenID' => $row['eval_id'])),
                'updated' => $row['startdate'],
                'summary' => sprintf('%s hat in der Einrichtung "%s" die Umfrage "%s" gestartet.',
                    $this->get_homepage($row), $row['Name'], $row['title']),
                'content' => $row['text'],
                'category' => 'survey'
            );
        }

        $items = array_map(array($this, 'add_time_in_words'), $items);

        // sort everything

        usort($items, create_function('$a, $b', 'return $b["updated"] - $a["updated"];'));
        $items = array_slice($items, 0, 100);

        return compact("title", "items");
    }

    function add_time_in_words($item) {
        $item['time_in_words'] = 'vor ' . $this->distance_of_time_in_words($item['updated']);
        return $item;
    }

    function distance_of_time_in_words($from_time, $to_time = null, $include_seconds = false) {

      $to_time = $to_time ? $to_time: time();

      $distance_in_minutes = floor(abs($to_time - $from_time) / 60);
      $distance_in_seconds = floor(abs($to_time - $from_time));

      $string = '';
      $parameters = array();

      if ($distance_in_minutes <= 1) {
        if (!$include_seconds) {
          $string = $distance_in_minutes == 0 ? _('weniger als eine Minute') : _('1 Minute');
        } else {
          if ($distance_in_seconds <= 5) {
            $string = _('weniger als 5 Sekunden');
          } else if ($distance_in_seconds >= 6 && $distance_in_seconds <= 10) {
            $string = _('weniger als 10 Sekunden');
          } else if ($distance_in_seconds >= 11 && $distance_in_seconds <= 20) {
            $string = _('weniger als 20 Sekunden');
          } else if ($distance_in_seconds >= 21 && $distance_in_seconds <= 40) {
            $string = _('eine halbe Minute');
          } else if ($distance_in_seconds >= 41 && $distance_in_seconds <= 59) {
            $string = _('weniger als eine Minute');
          } else {
            $string = _('1 Minute');
          }
        }
      } else if ($distance_in_minutes >= 2 && $distance_in_minutes <= 44) {
        $string = _('%minutes% Minuten');
        $parameters['%minutes%'] = $distance_in_minutes;
      } else if ($distance_in_minutes >= 45 && $distance_in_minutes <= 89) {
        $string = _('ca. 1 Stunde');
      } else if ($distance_in_minutes >= 90 && $distance_in_minutes <= 1439) {
        $string = _('ca. %hours% Stunden');
        $parameters['%hours%'] = round($distance_in_minutes / 60);
      } else if ($distance_in_minutes >= 1440 && $distance_in_minutes <= 2879) {
        $string = _('1 Tag');
      } else if ($distance_in_minutes >= 2880 && $distance_in_minutes <= 43199) {
        $string = _('%days% Tagen');
        $parameters['%days%'] = round($distance_in_minutes / 1440);
      } else if ($distance_in_minutes >= 43200 && $distance_in_minutes <= 86399) {
        $string = _('ca. 1 Monat');
      } else if ($distance_in_minutes >= 86400 && $distance_in_minutes <= 525959) {
        $string = _('%months% Monaten');
        $parameters['%months%'] = round($distance_in_minutes / 43200);
      } else if ($distance_in_minutes >= 525960 && $distance_in_minutes <= 1051919) {
        $string = _('ca. ein Jahr');
      } else {
        $string = _('�ber %years% Jahren');
        $parameters['%years%'] = round($distance_in_minutes / 525960);
      }

      return strtr($string, $parameters);
    }
}
?>
