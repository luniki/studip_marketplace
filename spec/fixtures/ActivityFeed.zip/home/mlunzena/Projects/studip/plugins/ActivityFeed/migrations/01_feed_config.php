<?php
/*
 * ActivityFeed.class.php - activity feed plugin for Stud.IP
 * Copyright (c) 2010  Elmar Ludwig
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 */

class FeedConfig extends Migration
{
    function description()
    {
        return 'initialize hash key for ActivityFeed plugin';
    }

    function up()
    {
        $db = DBManager::get();
        $key = '';

        for ($i = 0; $i < 32; ++$i) {
            $key .= chr(mt_rand(0, 63) + 48);
        }

        $name = 'ACTIVITY_FEED_KEY';
        $description = 'hash key for ActivityFeed plugin';
        $key = $db->quote($key);
        $time = time();

        $db->exec("
            INSERT INTO config
                (config_id, field, value, is_default, type, mkdate, chdate, description)
            VALUES
                (MD5('$name'), '$name', $key, 1, 'string', $time, $time, '$description')
        ");
    }

    function down()
    {
        $db = DBManager::get();

        $db->exec("DELETE FROM config WHERE field = 'ACTIVITY_FEED_KEY'");
    }
}
