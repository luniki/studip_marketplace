<link rel="alternate"
      type="application/atom+xml"
      title="ActivityFeed"
      href="<?= PluginEngine::getLink("activityfeed/atom/$user_id/$key") ?>">
