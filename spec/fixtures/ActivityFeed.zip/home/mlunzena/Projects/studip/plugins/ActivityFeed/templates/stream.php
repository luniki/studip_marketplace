<?
$this->set_layout($GLOBALS['template_factory']->open('layouts/base_without_infobox'));
?>
<style>
#layout_container {
    background: transparent;
    position: relative;
    padding-left: 0 !important;
    padding-top: 0 !important;
}

#filter {
    background: #17305d;
    width: 70px;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    margin: 0;
    padding: 0;
}

#filter li {
    list-style: none;
    padding-top: 1em;
}

#stream {
    background: #e0e0e0;
    padding-top: 1em;
}

#stream .author {
    position: absolute;
    left: -100px;
    top: 0px;
    width: 100px;
    overflow: hidden;
}

#stream .author img {
    height: 50px;
    width: 40px;
    display: block;
    margin-bottom: 0.5em;
}

#stream li {
    background: white;
    list-style: none;
    margin-left: 150px;
    min-height: 100px;
    position: relative;
    padding: 0.5em;
    margin-right: 1em;
    margin-bottom: 1em;
    -moz-border-radius:10px;
    -webkit-border-radius:10px;
    border-radius:10px;
}

#stream .date {
    position: absolute;
    top: 0.5em;
    right: 0.5em;
    color: #aaa;
}

#stream h2 {
    font-size: 1.2em;
    padding: 0 0 1em 0;
    margin: 0;
}

</style>
<ul id=filter>
    <li><?= Assets::img('header_home.gif') ?></li>
    <li><?= Assets::img('header_meinesem.gif') ?></li>
    <li><?= Assets::img('header_nachricht.gif') ?></li>
</ul>
<ul id=stream>
    <? foreach ($items as $item): ?>
        <li class="<?= htmlReady($item['category']) ?>">
            <span class=author>
                <?= Avatar::getAvatar($item['author_id'])->getImageTag(Avatar::MEDIUM) ?>
                <?= htmlReady($item['author']) ?>
            </span>
            <h2>
                <a href="<?= htmlReady($item['link']) ?>"><?= htmlReady($item['title']) ?></a>
            </h2>
            <span class=date><?= $item['time_in_words'] ?></span>
            <div class=summary>
                <?= strip_tags($item['summary']) ?>
            </div>
        </li>
    <? endforeach ?>
</ul>
